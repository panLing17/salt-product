<template>
  <div id="app" class="fs_16">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style lang="stylus">
@import './assets/css/reset.styl'
#app
    height 100%
</style>
