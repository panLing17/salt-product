/*
* 接口配置
* */
import Vue from 'vue'

Vue.prototype.$apiPath = process.env.API + process.env.API_PATH
Vue.prototype.$api = process.env.API
