// 字典
let dictionaryData = {}
// 权限资源
let listByUser = []
// 区域列表
let areaList = {}
// 未审核数量
let count = 0

export default {
  dictionaryData,
  listByUser,
  areaList,
  count
}
