<template>
    <div class="l-table">

    </div>
</template>

<script>
export default {
  name: 'l-table'
}
</script>

<style lang="stylus">

</style>