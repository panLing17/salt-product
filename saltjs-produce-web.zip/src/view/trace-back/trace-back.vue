<template>
    <div class="trace-back">
        <div class="top-card white-bg">
            <!--<div class="top-title view-title">查询</div>-->
            <div class="search-wrap fs_20">
                <label class="label-1">产品名称</label>
                <el-select v-model="search.reqParam.productCode" filterable  clearable placeholder="">
                    <el-option
                            v-for="item in productList"
                            :key="item.productCode"
                            :label="item.productName"
                            :value="item.productCode">
                    </el-option>
                </el-select>
                <label class="label-2"><span style="color: #D91C1C;margin-right: 5px">*</span>生产批号</label>
                <input type="text" v-model="search.reqParam.batch">
                <l-button v-if="btnPromise.search" :style="{'margin': '11px 1em 11px 2.5em'}" buttonText="查询" @button-click="getTraceList" iconName="iconfont icon-chaxx"></l-button>
                <l-button buttonText="清空" :style="{'margin': '11px 0'}" iconName="iconfont icon-qingk" @button-click="clear"></l-button>
            </div>
        </div>
        <div class="bottom-card white-bg fs_20">
            <div class="view-title">批次追溯列表</div>
            <div class="table-wrap fs_20" style="max-height: 10em;overflow: auto" v-show="searchList.length">
                <table class="table-header">
                    <colgroup width="5%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="11%"></colgroup>
                    <tr class="tr">
                        <th class="th"></th>
                        <th class="th">产品编码</th>
                        <th class="th">产品名称</th>
                        <th class="th">生产批号</th>
                        <th class="th">规格</th>
                        <th class="th">碘盐标志</th>
                        <th class="th">每箱含量</th>
                        <th class="th">计划产量</th>
                        <th class="th">实际产量</th>
                    </tr>
                </table>
                <table class="table">
                    <colgroup width="5%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="12%"></colgroup>
                    <colgroup width="11%"></colgroup>
                    <tr class="tr" v-for="(item, index) in searchList">
                        <td class="td center" @click="itemActive=index">
                            <i class="iconfont fs_20"
                               :class="{'icon-wd-': itemActive===index, 'icon-wd': itemActive!==index}"
                               :style="{color: itemActive===index?'#5F7FD9':'#414141'}"
                            ></i>
                        </td>
                        <td class="td">{{item.productCode}}</td>
                        <td class="td">{{item.productName}}</td>
                        <td class="td">{{item.batch}}</td>
                        <td class="td">{{item.spec}}</td>
                        <td class="td">{{item.iodate}}</td>
                        <td class="td">{{item.boxRatio}}</td>
                        <td class="td">{{item.plans}}</td>
                        <td class="td">{{item.weight}}</td>
                    </tr>
                </table>
            </div>
            <div class="tab-wrap fs_20">
                <div class="tab-item" :class="{active: tabItemActive===0}" @click="tabItemActive=0">
                    <span>产品信息</span>
                </div>
                <div class="tab-item" :class="{active: tabItemActive===1}" @click="tabItemActive=1">
                    <span>生产批次信息</span>
                </div>
                <div class="tab-item" :class="{active: tabItemActive===2}" @click="tabItemActive=2">
                    <span>批次投料信息</span>
                </div>
                <div class="tab-item" :class="{active: tabItemActive===3}" @click="tabItemActive=3">
                    <span>批次生产任务信息</span>
                </div>
                <div class="tab-item" :class="{active: tabItemActive===4}" @click="tabItemActive=4">
                    <span>抽检信息</span>
                </div>
                <div class="tab-item" :class="{active: tabItemActive===5}" @click="tabItemActive=5">
                    <span>检验信息</span>
                </div>
                <div class="tab-item" :class="{active: tabItemActive===6}" @click="tabItemActive=6">
                    <span>出入库信息</span>
                </div>
            </div>
            <div class="tab-content clear-float" v-show="tabItemActive===0">
                <div class="img">
                    <img :src="product.imgs[0]?product.imgs[0].img:''" @click="$method.magnifier(product.imgs[0]?product.imgs[0].img:'')" @error="$method.imgError($event)" alt="">
                </div>
                <table class="table right">
                    <tr class="tr">
                        <td class="td">产品编码</td>
                        <td class="td">{{product.productCode}}</td>
                        <td class="td">生产批号</td>
                        <td class="td">{{searchList[itemActive]?searchList[itemActive].batch:''}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">产品名称</td>
                        <td class="td">{{product.productName}}</td>
                        <td class="td">规格</td>
                        <td class="td">{{product.spec}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">碘盐标志</td>
                        <td class="td">{{product.iodate}}</td>
                        <td class="td">产品种类</td>
                        <td class="td">{{product.productCategory}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">包装方式</td>
                        <td class="td">{{product.packMethod}}</td>
                        <td class="td">每箱含量</td>
                        <td class="td">{{product.boxRatio}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">计划产量</td>
                        <td class="td">{{searchList[itemActive]?searchList[itemActive].plans:''}}</td>
                        <td class="td">实际产量</td>
                        <td class="td">{{searchList[itemActive]?searchList[itemActive].weight:''}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">保质期</td>
                        <td class="td">{{product.expiryDate}}个月</td>
                        <td class="td"></td>
                        <td class="td"></td>
                    </tr>
                </table>
            </div>
            <div class="tab-content" v-show="tabItemActive===1">
                <table class="table">
                    <tr class="tr">
                        <td class="td">生产批号</td>
                        <td class="td" colspan="3">{{batch.batch}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">建单人</td>
                        <td class="td">{{batch.applicant}}</td>
                        <td class="td">建单时间</td>
                        <td class="td">{{batch.applicantTime}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">计划产量</td>
                        <td class="td">{{batch.plans}}</td>
                        <td class="td">实际产量</td>
                        <td class="td">{{batch.weight}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">审核人</td>
                        <td class="td">{{batch.auditor}}</td>
                        <td class="td">审核时间</td>
                        <td class="td">{{batch.auditorTime}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">每托含量</td>
                        <td class="td">{{batch.tpRatio}}</td>
                        <td class="td">状态</td>
                        <td class="td">{{batch.status}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">结批时间</td>
                        <td class="td"></td>
                        <td class="td">放行时间</td>
                        <td class="td"></td>
                    </tr>
                </table>
            </div>
            <div class="tab-content" v-show="tabItemActive===2">
                <table class="table">
                    <tr class="tr">
                        <td class="td center">类型</td>
                        <td class="td center">物料名称</td>
                        <td class="td center">企业名称</td>
                        <td class="td center">出厂批号</td>
                        <td class="td center">投入量</td>
                        <td class="td center">投料点</td>
                        <td class="td center">操作人</td>
                        <td class="td center">投料时间</td>
                    </tr>
                    <tr class="tr" v-for="item in feeds">
                        <td class="td">{{item.masterType}}</td>
                        <td class="td">{{item.mName}}</td>
                        <td class="td">{{item.fName}}</td>
                        <td class="td">{{item.batchNo}}</td>
                        <td class="td">{{item.amount}}</td>
                        <td class="td">{{item.place}}</td>
                        <td class="td">{{item.feedUser}}</td>
                        <td class="td" style="overflow: hidden">{{item.feedTime}}</td>
                    </tr>
                </table>
            </div>
            <div class="tab-content" v-show="tabItemActive===3">
                <table class="table">
                    <tr class="tr">
                        <td class="td center">任务单号</td>
                        <td class="td center">车间单元产线名称</td>
                        <td class="td center">产线负责人</td>
                        <td class="td center">大箱完成量</td>
                        <td class="td center">小盒完成量</td>
                        <td class="td center">实际完成量</td>
                        <td class="td center">生产状态</td>
                    </tr>
                    <tr class="tr" v-for="item in tasks">
                        <td class="td">{{item.taskCode}}</td>
                        <td class="td">{{item.fullName}}</td>
                        <td class="td">{{item.lineChage}}</td>
                        <td class="td">{{item.codeCount}}</td>
                        <td class="td">{{item.boxCount}}</td>
                        <td class="td">{{item.weight}}</td>
                        <td class="td">{{item.status}}</td>
                    </tr>
                </table>
            </div>
            <div class="tab-content clear-float" v-show="tabItemActive===4">
                <div class="img">
                    <img :src="random.report" @click="$method.magnifier(random.report)" @error="$method.imgError($event)" alt="">
                </div>
                <table class="table right">
                    <tr class="tr">
                        <td class="td">检验单号</td>
                        <td class="td" colspan="3">{{random.billCode}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">取样日期</td>
                        <td class="td">{{random.sDate}}</td>
                        <td class="td">取样人</td>
                        <td class="td">{{random.sUser}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">收样日期</td>
                        <td class="td">{{random.aDate}}</td>
                        <td class="td">收样人</td>
                        <td class="td">{{random.aUser}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">检验依据</td>
                        <td class="td">{{random.tsBase}}</td>
                        <td class="td">检验结果</td>
                        <td class="td">{{random.tsResult}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">检测判定</td>
                        <td class="td">{{random.tsJudge}}</td>
                        <td class="td">检测人</td>
                        <td class="td">{{random.inspector}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">批准人</td>
                        <td class="td">{{random.approver}}</td>
                        <td class="td">报告日期</td>
                        <td class="td">{{random.reportDate}}</td>
                    </tr>
                </table>
            </div>
            <div class="tab-content clear-float" v-show="tabItemActive===5">
                <div class="img">
                    <img :src="check.report" @click="$method.magnifier(check.report)" @error="$method.imgError($event)" alt="">
                </div>
                <table class="table right">
                    <tr class="tr">
                        <td class="td">检验单号</td>
                        <td class="td">{{check.billCode}}</td>
                        <td class="td">报告日期</td>
                        <td class="td">{{check.reportDate}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">检测依据</td>
                        <td class="td">{{check.tsBase}}</td>
                        <td class="td">检验方法</td>
                        <td class="td">{{check.tsMethod}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">检验设备</td>
                        <td class="td">{{check.tsEqm}}</td>
                        <td class="td">检验结果</td>
                        <td class="td">{{check.tsResult}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">监测判定</td>
                        <td class="td">{{check.tsJudge}}</td>
                        <td class="td">检验人</td>
                        <td class="td">{{check.inspector}}</td>
                    </tr>
                    <tr class="tr">
                        <td class="td">审核人</td>
                        <td class="td">{{check.reviewer}}</td>
                        <td class="td">批准人</td>
                        <td class="td">{{check.approver}}</td>
                    </tr>
                </table>
            </div>
            <div class="tab-content" style="position: relative; height: 16em;" v-show="tabItemActive===6">
                <div style="height: 80%;overflow: auto">
                    <table class="table">
                        <tr class="tr">
                            <td class="td center">单据时间</td>
                            <td class="td center">客户</td>
                            <td class="td center">大箱数量</td>
                            <td class="td center">小盒数量</td>
                            <td class="td center">总重量</td>
                            <td class="td center">类型</td>
                        </tr>
                        <tr class="tr" v-for="item in data.dataList">
                            <td class="td">{{item.storageDay}}</td>
                            <td class="td">{{item.toName}}</td>
                            <td class="td">{{item.boxCount}}</td>
                            <td class="td">{{item.barCount}}</td>
                            <td class="td">{{item.weight}}</td>
                            <td class="td">{{item.billType}}</td>
                        </tr>
                    </table>
                </div>
                <l-page
                    :totalPage="data.total"
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :currentPage="params.reqParam.page"
            ></l-page>
            </div>
        </div>
    </div>
</template>

<script>
  import {pageCallback} from '@/assets/js/mixin'
  export default {
    name: 'trace-back',
    mixins: [pageCallback],
    data() {
      return {
        tabItemActive: 0,
        productList: [],
        search: {
          reqParam: {
            productCode: '',
            batch: ''
          }
        },
        data: {},
        itemActive: -1,
        product: {
          imgs:[]
        },
        batch: {},
        feeds: [],
        tasks: [],
        random: {},
        check: {},
        searchList: [],
        params:{
          reqParam: {
            page: 1,
            pageSize: 10,
            batchPkId: ''
          }
        }
      }
    },
    watch: {
      itemActive(newVal) {
        if(newVal>-1 && this.btnPromise.detail) {
          this.getInfo()
        }
      }
    },
    created () {
      this.getProductList()
    },
    methods: {
      getProductList() {
        this.$http({
          url: this.$api + 'produce/resources/rs/product/getForCombox',
          method: 'post',
          data: {
            reqParam: {
              productName: ''
            }
          }
        }).then(res => {
          if(res.data.retCode === 1) {
            this.productList = res.data.retVal
          }
        })
      },
      clear() {
        this.search.reqParam.batch = ''
      },
      getTraceList() {
        if(this.search.reqParam.batch.length === 0) {
          this.$message.warning('请输入批号')
          return
        }
        this.$http({
          url: this.$api + 'produce/production/trace/batch/list',
          method: 'post',
          data: this.search
        }).then(res => {
          if(res.data.retCode === 1) {
            res.data.retVal.forEach(item=>{
              item.iodate = this.$method.queryDictionary.call(this, 100, item.iodate)
            })
            this.searchList = res.data.retVal
            if(this.searchList.length>0) {
              this.itemActive = 0
            } else {
              this.itemActive = -1
              this.product = {
                imgs:[]
              }
              this.batch = {}
              this.feeds = []
              this.tasks = []
              this.random = {}
              this.check = {}
              this.data = {}
            }
          }
        })
      },
      getInfo() {
        this.getProduct()
        this.getBatch()
        this.getFeeds()
        this.getTasks()
        this.getRandom()
        this.getCheck()
        this.getData()
      },
      getProduct() {
        this.$http({
          url: this.$api + 'produce/resources/rs/product/getById',
          method: 'post',
          data: {
            reqParam: {
              productCode: this.searchList[this.itemActive].productCode
            }
          }
        }).then(res => {
          if(res.data.retCode === 1) {
            res.data.retVal.iodate = this.$method.queryDictionary.call(this, 100, res.data.retVal.iodate)
            this.product = res.data.retVal
          }
        })
      },
      getBatch() {
        this.$http({
          url: this.$api + 'produce/production/pd/batch/getById',
          method: 'post',
          data: {
            reqParam: {
              pkId: this.searchList[this.itemActive].pkId
            }
          }
        }).then(res => {
          if(res.data.retCode === 1) {
            res.data.retVal.status = this.$method.queryDictionary.call(this, 950, res.data.retVal.status)
            this.batch = res.data.retVal
          }
        })
      },
      getFeeds() {
        this.$http({
          url: this.$api + 'produce/production/pd/batch/feed/list',
          method: 'post',
          data: {
            reqParam: {
              batchPkId: this.searchList[this.itemActive].pkId
            }
          }
        }).then(res => {
          if(res.data.retCode === 1) {
            res.data.retVal.forEach(item=>{
              item.masterType = this.$method.queryDictionary.call(this, 930, item.masterType)
            })
            this.feeds = res.data.retVal
          }
        })
      },
      getTasks() {
        this.$http({
          url: this.$api + 'produce/production/pd/batch/task/list',
          method: 'post',
          data: {
            reqParam: {
              batchPkId: this.searchList[this.itemActive].pkId
            }
          }
        }).then(res => {
          if(res.data.retCode === 1) {
            res.data.retVal.forEach(item=>{
              item.status = this.$method.queryDictionary.call(this, 950, item.status)
            })
            this.tasks = res.data.retVal
          }
        })
      },
      getRandom() {
        this.$http({
          url: this.$api + 'produce/production/pd/batch/sampling/getByIdOrBatchPkId',
          method: 'post',
          data: {
            reqParam: {
              batchPkId: this.searchList[this.itemActive].pkId
            }
          }
        }).then(res => {
          if(res.data.retCode === 1) {
            this.random = res.data.retVal?res.data.retVal:{}
          }
        })
      },
      getCheck() {
        this.$http({
          url: this.$api + 'produce/production/pd/batch/inspect/getByIdOrBatchPkId',
          method: 'post',
          data: {
            reqParam: {
              batchPkId: this.searchList[this.itemActive].pkId
            }
          }
        }).then(res => {
          if(res.data.retCode === 1) {
            this.check = res.data.retVal?res.data.retVal:{}
          }
        })
      },
      getData() {
        this.params.reqParam.batchPkId = this.searchList[this.itemActive].pkId
        this.$http({
          url: this.$api + 'produce/production/trace/batch/saleList',
          method: 'post',
          data: this.params
        }).then(res => {
          if(res.data.retCode === 1) {
            res.data.retVal.dataList.forEach(item=>{
              item.billType = this.$method.queryDictionary.call(this, 960, item.billType)
            })
            this.data = res.data.retVal
          }
        })
      }
    }
  }
</script>

<style scoped lang="stylus">
    .trace-back
        width 100%
        height 100%
        .search-wrap
            .label-1
                margin 0 0.5em 0 2.85em
            input
                width 15%
            .label-2
                margin 0 0.5em 0 1em
        .table-wrap
            width 94.38%
            margin 0 auto
        .tab-wrap
            color #414141
            width 94.38%
            margin 0 auto
            .tab-item
                display inline-block
                line-height 3.9em
                padding 0 1.5em
                position relative
                cursor pointer
                &.active
                    color #5F7FD9
                    span
                        position relative
                        &:after
                            content ''
                            display block
                            height 2px
                            width 100%
                            background-color #5F7FD9
                            position absolute
                            bottom -.2em
                            left 0
                &:nth-of-type(1)
                    padding-left 0
                &:last-child
                    &:before
                        display none
                &:before
                    content ''
                    display block
                    width 1px
                    height 1.15em
                    background-color #E3E3E3
                    position absolute
                    right 0
                    top 50%
                    transform translateY(-50%)
        .tab-content
            width 94.38%
            margin 0 auto
            .img
                float left
                width 20%
                height 0
                padding-bottom 20%
                position relative
                bakcground-color #E3E3E3
                font-size 0
                img
                    position absolute
                    width 100%
                    height 100%
            .table
                &.right
                    float right
                    width 79%
                .tr
                    .td
                        height 2.6em
</style>
<style lang="stylus">
    .trace-back
        .el-select
            width 20%
        .el-input__icon
            line-height 2em
    .tab-content
        .l-page
            left 0
            .el-pagination__sizes
                left -6em
</style>
