import Information from './information'
import Information1 from './information-1'
import Information2 from './information-2'
import Information3 from './information-3'
import Information4 from './information-4'
import Information5 from './information-5'
import Information6 from './information-6'
export default {
  Information,
  Information1,
  Information2,
  Information3,
  Information4,
  Information5,
  Information6
}
