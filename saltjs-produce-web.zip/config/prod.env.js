'use strict'
module.exports = {
  NODE_ENV: '"production"',
  REQ_PRE: '"http://"',
  API_ROOT: '"192.168.100.254"',
  API_PORT:'":8095"',
  API_PATH: '"/produce/resources/rs/"',
  API: '"/api"'
}
